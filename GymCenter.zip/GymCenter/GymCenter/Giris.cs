﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymCenter
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=BRATACIE4A7;Initial Catalog=GYMCENTER;uid=sa;pwd=serdargok");

        private void button1_Click(object sender, EventArgs e)
        {
            //string kadi = textBox1.Text;
            //string sifre = textBox2.Text;
            //if (kadi == "kamer" && sifre == "1234")
            //{

            //    MessageBox.Show("Sayın " + kadi + " BAŞARIYLA GİRİŞ YAPTINIZ");

            //    Kayıt form2 = new Kayıt();//hangi ekrana gideceksek nesne üretiriz.
            //    this.Hide();// form1 ekranını gizlemek için              
            //    form2.Show();//ekranı açar
            //}
            //else
            //{
            //    MessageBox.Show("Şifre ve Kullanıcı Adı Yanlış.Tekrar Deneyiniz!!!");
            //}
            SqlCommand kmt = new SqlCommand();
            kmt.Connection = con;
            kmt.CommandType = CommandType.StoredProcedure;
            kmt.CommandText = "Giris";

            kmt.Parameters.AddWithValue("UserName", textBox1.Text);
            kmt.Parameters.AddWithValue("Password", textBox2.Text);

            con.Open();
            SqlDataReader rd;
            rd = kmt.ExecuteReader();

            if (rd.Read())
            { 
                Kayıt gr = new Kayıt();
                gr.Show();
                this.Hide();
            }
            else
            {
                textBox1.Clear();
                textBox2.Clear();
            }
            con.Close();
        }
    }
}
