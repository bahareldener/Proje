﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymCenter
{
    public partial class Rapor : Form
    {
        public Rapor()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=BRATACIE4A7;Initial Catalog=GYMCENTER;uid=sa;pwd=serdargok");
        private void Rapor_Load(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            button4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand();
            komut.Connection = con;
            komut.CommandType = CommandType.StoredProcedure;
            komut.CommandText = "MembersASırala"; 

            SqlDataAdapter dr = new SqlDataAdapter(komut);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand();
            kmt.Connection = con;
            kmt.CommandType = CommandType.StoredProcedure;
            kmt.CommandText = "MembersZsırala"; 

            SqlDataAdapter ad = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand kmt = new SqlCommand();
            kmt.Connection = con;
            kmt.CommandType = CommandType.StoredProcedure;
            kmt.CommandText = "MembersAdAra";

            kmt.Parameters.AddWithValue("NameSurname", textBox1.Text);

            SqlDataAdapter ad = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem=="Ad Soyad")
            {
                textBox2.Visible = true;
                button4.Visible = true;
            }
            else if (comboBox1.SelectedItem == "Boy")
            {
                textBox2.Visible = true;
                button4.Visible = true;
            }
            else if (comboBox1.SelectedItem == "Kilo")
            {
                textBox2.Visible = true;
                button4.Visible = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Ad Soyad")
            {
                con.Open();
                SqlCommand kmt = new SqlCommand();
                kmt.Connection = con;
                kmt.CommandType = CommandType.StoredProcedure;
                kmt.CommandText = "MembersAdAra";
                kmt.Parameters.AddWithValue("NameSurname", textBox2.Text);

                SqlDataAdapter ad = new SqlDataAdapter(kmt);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (comboBox1.SelectedItem == "Boy")
            {
                con.Open();
                SqlCommand kmt = new SqlCommand();
                kmt.Connection = con;
                kmt.CommandType = CommandType.StoredProcedure;
                kmt.CommandText = "MembersHeight";

                kmt.Parameters.AddWithValue("Height",textBox2.Text);

                SqlDataAdapter ad = new SqlDataAdapter(kmt);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else if (comboBox1.SelectedItem == "Kilo")
            {   con.Open();
                SqlCommand kmt = new SqlCommand();
                kmt.Connection = con;
                kmt.CommandType = CommandType.StoredProcedure;
                kmt.CommandText = "MembersZsırala";

                kmt.Parameters.AddWithValue("Weight", textBox2.Text);

                SqlDataAdapter ad = new SqlDataAdapter(kmt);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            SqlCommand kmt = new SqlCommand("select  top 1 * from Members order by Height", con);
           
            SqlDataAdapter ad = new SqlDataAdapter(kmt);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem=="AD SOYAD")
            {
                
                SqlCommand cmd = new SqlCommand("select * from Members order by NameSurname desc",con);
                con.Open();
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource= dt;
                con.Close();
            }
            else if (comboBox2.SelectedItem=="KİLO")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from Members order by Weight",con);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource= dt;
                con.Close();
            }
            else if (comboBox2.SelectedItem=="BOY")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from Members order by Height desc", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource= dt;
                con.Close();
            }
            else 
            {
                con.Open();
                SqlCommand sql = new SqlCommand("select * from Members order by Age desc", con);
                SqlDataAdapter da = new SqlDataAdapter(sql);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource= dt;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Kayıt go = new Kayıt();
            go.Show();
            this.Hide();
        }
    }
}
