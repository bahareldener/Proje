﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//sql kütüphanemiz
namespace GymCenter
{
    public partial class UyeEkrani : Form
    {
        public UyeEkrani()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection("Data Source=BRATACIE4A7;Initial Catalog=GYMCENTER;uid=sa;pwd=serdargok");

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();            // form1 ekranını gizlemek için
            Kayıt go = new Kayıt();//hangi ekrana gideceksek nesne üretiriz.
            go.Show();              //ekranı açar
        }
        public void Listeleme ()//Listelemeyi metot olarak yazıyoruz.her ekleme,silme,güncelleme yaptığımızda görmek için direkt metot olarak çağıracağız.
        {
            SqlCommand komut = new SqlCommand();
            komut.Connection = conn;
            komut.CommandType = CommandType.StoredProcedure;
            komut.CommandText = "MembersListele"; //Listeleme procedur adımız.
            SqlDataAdapter dr = new SqlDataAdapter(komut);//Sql'e gidip verileri alacak
            DataTable dt = new DataTable();     //verileri düzenli hale getirir
            dr.Fill(dt);
            dataGridView1.DataSource = dt;      //form ekranında göstermek için
        }
        private void UyeEkrani_Load(object sender, EventArgs e)
        {
            //Şube
            conn.Open();
            SqlCommand sube = new SqlCommand("Select * from Substations", conn);         
            SqlDataReader dr= sube.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["SubstationId"]);
            }
            conn.Close();

            //Branş
            conn.Open();
            SqlCommand brans = new SqlCommand("Select * from  Departments", conn);          
            SqlDataReader datr = brans.ExecuteReader();
            while (datr.Read())
            {
                comboBox2.Items.Add(datr["DepartmentId"]);
            }
            conn.Close();

            //Eğitmen
            conn.Open();
            SqlCommand Egitmen = new SqlCommand("Select * from  Trainers", conn);          
            SqlDataReader egitmen = Egitmen.ExecuteReader();
            while (egitmen.Read())
            {
                comboBox3.Items.Add(egitmen["TrainerId"]);
            }
            conn.Close();

            //Paket
            conn.Open();
            SqlCommand Paket = new SqlCommand("Select * from  Memberships", conn);          
            SqlDataReader paket = Paket.ExecuteReader();
            while (paket.Read())
            {
                comboBox4.Items.Add(paket["MembershipId"]);
            }         
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Listeleme();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Ekle,Kaydet Butonu
            conn.Open();//veritabanında değişiklik yapılacaksa aç kapa işlemi yapılır.
            SqlCommand komut = new SqlCommand();
            komut.Connection = conn;
            komut.CommandType = CommandType.StoredProcedure;
            komut.CommandText = "MembersEkle";

            komut.Parameters.AddWithValue("NameSurname",textBox1.Text);
            komut.Parameters.AddWithValue("Gender", textBox2.Text);
            komut.Parameters.AddWithValue("Age", textBox3.Text);
            komut.Parameters.AddWithValue("Height", textBox4.Text);
            komut.Parameters.AddWithValue("Weight", textBox5.Text);
            komut.Parameters.AddWithValue("Address", textBox6.Text);
            komut.Parameters.AddWithValue("MemberDate", dateTimePicker1.Text);
            komut.Parameters.AddWithValue("SubstationId", comboBox1.Text);
            komut.Parameters.AddWithValue("DepartmentId", comboBox2.Text);
            komut.Parameters.AddWithValue("TrainerId", comboBox3.Text);

            komut.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Yeni Üye Eklendi");
            Listeleme();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Güncelle, Yenile Butonu
            conn.Open();
            SqlCommand komut = new SqlCommand();
            komut.Connection = conn;
            komut.CommandType = CommandType.StoredProcedure;
            komut.CommandText = "MembersYenile";

            komut.Parameters.AddWithValue("MemberId",textBox1.Tag);
            komut.Parameters.AddWithValue("NameSurname", textBox1.Text);
            komut.Parameters.AddWithValue("Gender", textBox2.Text);
            komut.Parameters.AddWithValue("Age", textBox3.Text);
            komut.Parameters.AddWithValue("Weight", textBox4.Text);
            komut.Parameters.AddWithValue("Height", textBox5.Text);
            komut.Parameters.AddWithValue("Address", textBox6.Text);
            komut.Parameters.AddWithValue("MemberDate", dateTimePicker1.Text);
            komut.Parameters.AddWithValue("SubstationId", comboBox1.Text);
            komut.Parameters.AddWithValue("DepartmentId", comboBox2.Text);
            komut.Parameters.AddWithValue("TrainerId", comboBox3.Text);

            komut.ExecuteNonQuery();
            conn.Close();
            Listeleme();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow satir = dataGridView1.CurrentRow;
            textBox1.Tag = satir.Cells["MemberId"].Value.ToString();
            textBox1.Text = satir.Cells["NameSurname"].Value.ToString();
            textBox2.Text = satir.Cells["Gender"].Value.ToString();
            textBox3.Text = satir.Cells["Age"].Value.ToString();
            textBox4.Text = satir.Cells["Height"].Value.ToString();
            textBox5.Text = satir.Cells["Weight"].Value.ToString();
            textBox6.Text = satir.Cells["Address"].Value.ToString();
            dateTimePicker1.Text = satir.Cells["MemberDate"].Value.ToString();
            comboBox1.Text = satir.Cells["SubstationId"].Value.ToString();
            comboBox2.Text = satir.Cells["DepartmentId"].Value.ToString();
            comboBox3.Text = satir.Cells["TrainerId"].Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from Members where NameSurname like '"+textBox1.Text+"'",conn);  
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //prosedürlü olarak sil işlemini henüz yazmadık.
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            SqlCommand cmd = new SqlCommand("Select Price from Memberships",conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read()) 
            {
                textBox7.Text = dr["Price"].ToString();
            }
            conn.Close();
        }
    }
}
