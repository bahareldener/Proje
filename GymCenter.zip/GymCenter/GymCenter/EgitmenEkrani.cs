﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymCenter
{
    public partial class EgitmenEkrani : Form
    {
        public EgitmenEkrani()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection("Data Source=BRATACIE4A7;Initial Catalog=GYMCENTER;uid=sa;pwd=serdargok");
        private void EgitmenEkrani_Load(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from Substations",conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["SubstationId"]);
            }
            conn.Close();

            conn.Open();
            SqlCommand sql = new SqlCommand("select * from Departments", conn);
            SqlDataReader r = sql.ExecuteReader();
            while (r.Read())
            {
                comboBox2.Items.Add(r["DepartmentId"]);
            }
            conn.Close();
        }


        public void Listeleme(string komut)
        {
            //SqlCommand komut = new SqlCommand();
            //komut.Connection = con;
            //komut.CommandType = CommandType.StoredProcedure;
            //komut.CommandText = "TrainersListele";

            SqlDataAdapter da = new SqlDataAdapter(komut,conn); //adapter aracı oluyor.
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt; //Formda göstermek için yazdık.
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();// form1 ekranını gizlemek için
            Kayıt go = new Kayıt();//hangi ekrana gideceksek nesne üretiriz.
            go.Show();//ekranı açar
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Listeleme("select * from Trainers");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into Trainers (NameSurname,SubstationId, DepartmentId,Gender) values (@NameSurname,@SubstationId,@DepartmentId,@Gender)",conn);

            cmd.Parameters.AddWithValue("@NameSurname",textBox1.Text);
            cmd.Parameters.AddWithValue("@Gender",textBox2.Text);
            cmd.Parameters.AddWithValue("@SubstationId",comboBox1.Text);
            cmd.Parameters.AddWithValue("@DepartmentId", comboBox2.Text);

            cmd.ExecuteNonQuery();
            conn.Close();
            Listeleme("select * from Trainers");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("update Trainers set NameSurname='"+textBox1.Text.ToString()+"',Gender='"+textBox2.Text.ToString()+"',SubstationId='"+comboBox1.Text.ToString()+"',DepartmentId='"+comboBox2.Text.ToString()+"',Gender='"+textBox3.Text.ToString()+"'");

            cmd.ExecuteNonQuery();
            conn.Close();
            Listeleme("select * from Trainers");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("delete from Trainers where TrainerId=@TrainerId",conn);

            cmd.Parameters.AddWithValue("@TrainerId",textBox1.Tag);

            cmd.ExecuteNonQuery();
            conn.Close();
            Listeleme("select * from Trainers");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow yaz = dataGridView1.CurrentRow;
            textBox1.Tag = yaz.Cells["TrainerId"].Value.ToString();
            textBox2.Text = yaz.Cells["NameSurname"].Value.ToString();
            textBox3.Text= yaz.Cells["Gender"].Value.ToString() ;
            comboBox1.Text = yaz.Cells["SubstationId"].Value.ToString();
            comboBox2.Text = yaz.Cells["DepartmentId"].Value.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from Trainers where NameSurname like '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
