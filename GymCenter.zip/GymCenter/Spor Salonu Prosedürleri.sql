--Departments Silme
create proc DepartmentSil
@DepartmentId tinyint
as begin
delete from Departments
where DepartmentId=@DepartmentId
end

--Departments Yenileme   
create proc DepartmentsYenile
@DepartmentId tinyint,
@DepartmentName varchar(20)
as begin update Departments
set DepartmentName=@DepartmentName
where DepartmentId=@DepartmentId
end


 --Departments Ekleme
 create proc DepartmentsEkle
 @DepartmentName varchar(20)
 as begin
 insert into Departments(DepartmentName)
 values(@DepartmentName)
 end

 --Departments Listeleme
 create proc DepartmentsListele
 as begin
 select * from Departments
 end

 --Substation ekleme
 create proc SubstationsEkle
 @SubstationName varchar(20)
 as begin
 insert into Substations(SubstationName)
 values ( @SubstationName)
 end

 --Substation Listeleme
  create proc SubstationsListele
  as begin
  select * from Substations end

  --Substatiton Silme
create proc SubstationsSil
@SubstationId tinyint
as begin
delete from Substations
where SubstationId=@SubstationId end

--Substation Yenileme --Hata Veriyor
create proc SubstationsYenile
@SubstationId tinyint,
@SubstationName varchar(20)
as begin update Substations
set SubstationName=@SubstationName
where SubstationId=@SubstationId
end

--Departments Silme
create proc DepartmentsSil
@DepartmentId tinyint
as begin
delete from Departments
where DepartmentId=@DepartmentId
end

--Departments Yenileme   
create proc DepartmentsYenile
@DepartmentId tinyint,
@DepartmentName varchar(20)
as begin update Departments
set DepartmentName=@DepartmentName
where DepartmentId=@DepartmentId
end

 --Departments Ekleme
 create proc DepartmentsEkle
 @DepartmentName varchar(20)
 as begin
 insert into Departments(DepartmentName)
 values(@DepartmentName)
 end

 --Departments Listeleme
 create proc DepartmentsListele
 as begin
 select * from Departments
 end

 --Substation ekleme
 create proc SubstationsEkle
 @SubstationName varchar(20)
 as begin
 insert into Substations(SubstationName)
 values ( @SubstationName)
 end

 --Substation Listeleme
  create proc SubstationsListele
  as begin
  select * from Substations end

  --Substatiton Silme
create proc SubstationsSil
@SubstationId tinyint
as begin
delete from Substations
where SubstationId=@SubstationId end

--Substation Yenileme 
create proc SubstationsYenile
@SubstationId tinyint,
@SubstationName varchar(20)
as begin update Substations
set SubstationName=@SubstationName
where SubstationId=@SubstationId
end

--Departments Silme
create proc DepartmentsSil
@DepartmentId tinyint
as begin
delete from Departments
where DepartmentId=@DepartmentId
end

--Departments Yenileme   
create proc DepartmentsYenile
@DepartmentId tinyint,
@DepartmentName varchar(20)
as begin update Departments
set DepartmentName=@DepartmentName
where DepartmentId=@DepartmentId
end

 --Departments Ekleme
 create proc DepartmentsEkle
 @DepartmentName varchar(20)
 as begin
 insert into Departments(DepartmentName)
 values(@DepartmentName)
 end

 --Departments Listeleme
 create proc DepartmentsListele
 as begin
 select * from Departments
 end

 --Substation ekleme
 create proc SubstationsEkle
 @SubstationName varchar(20)
 as begin
 insert into Substations(SubstationName)
 values ( @SubstationName)
 end

 --Substation Listeleme
  create proc SubstationsListele
  as begin
  select * from Substations end

  --Substatiton Silme
create proc SubstationsSil
@SubstationId tinyint
as begin
delete from Substations
where SubstationId=@SubstationId end

--Substation Yenileme 
create proc SubstationsYenile
@SubstationId tinyint,
@SubstationName varchar(20)
as begin update Substations
set SubstationName=@SubstationName
where SubstationId=@SubstationId
end

 --Trainers Listeleme
 create proc TrainersListele
 as begin
 select * from Trainers
 end

 --Trainers Ekleme
 create proc TrainersEkle
 @NameSurname varchar(20),
 @SubstationId tinyint,
 @DepartmentId tinyint,
 @Gender varchar(5)
 as begin
 insert into Trainers(NameSurname,SubstationId,DepartmentId,Gender)
 values ( @NameSurname, @SubstationId,@DepartmentId, @Gender)
 end

 --Trainers silme
 create proc TrainersSil
 @TrainerId tinyint
 as begin
 delete from Trainers
 where TrainerId=@TrainerId end


 --Trainers Yenileme
 create proc TrainersYenile
@TrainerId tinyint,
@NameSurname varchar(20),
@SubstationId tinyint,
@DepartmentId tinyint,
@Gender varchar(5)
as begin update Trainers
set NameSurname=@NameSurname,SubstationId=@SubstationId,DepartmentId=@DepartmentId,Gender=@Gender
where TrainerId=@TrainerId end

--Memberships Listeleme
create proc MembershipsListele
as begin
select * from Memberships
end

--Memberships Ekleme
create proc MembershipsEkle
@MembershipName varchar(20),
@Price float,
@MemberId tinyint
as begin
insert into Memberships(MembershipName,Price,MemberId)
values (@MembershipName,@Price,@MemberId)
end

--Memberships Yenileme
create proc MembershipsYenile
@MembershipId tinyint,
@MembershipName varchar(20),
@Price float,
@MemberId tinyint
as begin update Memberships
set MembershipName=@MembershipName, Price=@Price, MemberId=@MemberId
where MembershipId=@MembershipId
end

--Memberships Silme
create proc MembershipsSil
@MembershipsId tinyint
as begin 
delete from Memberships
where MembershipId=@MembershipsId end

--Members Listeleme
 create proc MembersListele
 as begin
 select * from Members
 end


--Member Ekleme
create proc MembersEkle
@NameSurname varchar(20),
@Gender varchar(5),
@Age int,
@Height int,
@Weight int,
@Address varchar(50),
@MemberDate varchar(20),
@SubstationId int,
@DepartmentId int,
@TrainerId int,
@MembershipId int
as begin 
insert into Members(NameSurname,Gender,Age,Height,Weight,Address,MemberDate,SubstationId,DepartmentId,TrainerId,MembershipId)
values (@NameSurname,@Gender,@Age,@Height,@Weight,@Address,@MemberDate,@SubstationId,@DepartmentId,@TrainerId,@MembershipId)
end 



--Member Sil
create proc MembersSil
@MemberId tinyint
as begin delete from Members 
where MemberId=@MemberId end


--Member Yenile
create proc MembersYenile
@MemberId tinyint,
@NameSurname varchar(20),
@Gender varchar(5),
@Age int,
@Height int,
@Weight int,
@Address varchar(50),
@MemberDate varchar(20),
@SubstationId int,
@DepartmentId int,
@TrainerId int,
@MembershipId int
as begin update Members
set NameSurname=@NameSurname,Gender=@Gender,Age=@Age,Height=@Height,Weight=@Weight,
Address=@Address,MemberDate=@MemberDate,SubstationId=@SubstationId,DepartmentId=@DepartmentId,TrainerId=@TrainerId,MembershipId=@MembershipId
where MemberId=@MemberId

end

create proc MembersAS�rala
as begin
select * from Members order by NameSurname asc
end

create proc MembersZs�rala
as begin
select * from Members order by Weight asc
end

create proc MembersAdAra
@NameSurname varchar(20)
as begin 
select * from Members where NameSurname=@NameSurname
end

create proc MembersHeight
as begin
select * from Members order by Height asc
end

create proc Giris
@UserName varchar(20),
@Password varchar(5)
as begin
select * from Users where
UserName=@UserName and Password=@Password
end

select  top 1 * from Members order by Height